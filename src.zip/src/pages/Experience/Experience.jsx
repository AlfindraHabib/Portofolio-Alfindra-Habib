import React, { useRef } from "react";
import { motion, useScroll, useTransform } from "framer-motion";
import { Code2, Activity, Cpu, Layers, Network, Binary } from "lucide-react";

// Diurutkan kronologis (2023 -> 2026). `year` dipakai sebagai penanda
// kelompok tahun di sepanjang rel; `hasIp` menandai riset yang
// menghasilkan Hak Cipta terdaftar DJKI.
const experiences = [
  {
    year: "2023",
    icon: Network,
    title: "Menteri Jurnalistik",
    company: "BEM Universitas Jenderal Achmad Yani Yogyakarta",
    period: "2023 - 2024",
    description:
      "Mengelola dan mengembangkan website resmi BEM, mengoordinasikan tim jurnalistik, serta mempublikasikan konten dan berita kegiatan organisasi secara digital.",
    hasIp: false,
  },
  {
    year: "2025",
    icon: Layers,
    title: "Proyek PjBL - Luxe Jogja: Sistem Rekomendasi Penginapan",
    company: "Universitas Jenderal Achmad Yani Yogyakarta",
    period: "Jan 2025",
    description:
      "Membangun sistem rekomendasi penginapan untuk destinasi wisata Yogyakarta menggunakan React & Flask; terdaftar sebagai Hak Cipta Program Komputer \u201cLuxe Jogja - Sistem Rekomendasi Penginapan Area Wisata Yogyakarta\u201d di DJKI (No. Pencatatan 000864700).",
    hasIp: true,
  },
  {
    year: "2025",
    icon: Code2,
    title: "Fullstack Developer (Magang)",
    company: "PT Teknologi Server Indonesia (Xcode)",
    period: "Jul - Sep 2025",
    description:
      "Mengembangkan aplikasi web & sistem internal menggunakan Laravel, React, dan Supabase, termasuk chatbot otomatis berbasis API dan optimalisasi performa website.",
    hasIp: false,
  },
  {
    year: "2025",
    icon: Binary,
    title: "Peneliti Mahasiswa - Sistem Pakar Deteksi Hama & Penyakit Padi (Aplikasi Agripadi)",
    company: "Universitas Jenderal Achmad Yani Yogyakarta",
    period: "Sep 2025",
    description:
      "Mengembangkan sebuah aplikasi sistem pakar bersama dosen; terdaftar sebagai Hak Cipta Program Komputer \u201cImplementasi Metode Certainty Factor Untuk Mendeteksi Hama Penyakit Pada Tanaman Padi\u201d di DJKI (No. Pencatatan 000964211), dengan React sebagai frontend & Flask sebagai backend.",
    hasIp: true,
  },
  {
    year: "2026",
    icon: Activity,
    title: "Pengembangan Sistem Pakar Untuk Diagnosis Penyakit Daun Pada Tanaman Padi Menggunakan Metode Certainty Factor (Website Padi Waras)",
    company: "Universitas Jenderal Achmad Yani Yogyakarta",
    period: "Jul 2026",
    description:
      "Luaran kedua dari riset Sistem Pakar Deteksi Hama & Penyakit Padi bersama dosen: sistem web Padi Waras untuk diagnosis penyakit daun tanaman padi, dibangun dengan React + Vite (frontend) dan Flask (backend); terdaftar sebagai Hak Cipta Program Komputer di DJKI (No. Pencatatan 001379272).",
    hasIp: true,
  },
  {
    year: "2026",
    icon: Cpu,
    title: "Peneliti Skripsi - Farmonaut",
    company: "Universitas Jenderal Achmad Yani Yogyakarta",
    period: "2026",
    description:
      "Skripsi: \u201cKlasifikasi Penyakit Daun Padi Berbasis Citra Menggunakan Arsitektur MobileNetV2 pada Aplikasi Mobile\u201d. Membandingkan 3 model CNN Transfer Learning (MobileNetV2, VGG16, NASNetMobile) dengan akurasi \u00B197%, diimplementasikan ke aplikasi mobile berbasis Flutter & Flask.",
    hasIp: false,
  },
];

const YearMarker = ({ year }) => (
  <div className="relative mb-6 mt-2 pl-[72px] sm:pl-20">
    <span className="select-none text-5xl font-bold text-white/[0.06] sm:text-6xl">
      {year}
    </span>
  </div>
);

const TimelineItem = ({ icon: Icon, title, company, period, description, hasIp }) => (
  <div className="relative flex gap-6 sm:gap-8">
    <div className="relative z-10 flex h-10 w-10 shrink-0 items-center justify-center rounded-full border border-amber-500/40 bg-[#04081A] text-amber-400">
      <Icon className="h-4 w-4" />
    </div>

    <div className="flex-1 pb-12">
      <div className="mb-2 flex flex-wrap items-center gap-x-3 gap-y-1">
        <span className="font-mono text-xs text-amber-400/80">{period}</span>
        {hasIp && (
          <span className="rounded-full border border-amber-400/30 px-2 py-0.5 text-[10px] font-medium text-amber-400/90">
            Hak Cipta terdaftar
          </span>
        )}
      </div>
      <h3 className="text-xl font-bold text-white sm:text-2xl">{title}</h3>
      <p className="mt-1 text-sm font-medium text-gray-400">{company}</p>
      <p className="mt-3 max-w-2xl leading-relaxed text-gray-300/90">{description}</p>
    </div>
  </div>
);

const ExperienceSection = () => {
  const railRef = useRef(null);
  const { scrollYProgress } = useScroll({
    target: railRef,
    offset: ["start 0.75", "end 0.6"],
  });
  const progressHeight = useTransform(scrollYProgress, [0, 1], ["0%", "100%"]);

  let lastYear = null;

  return (
    <div className="relative overflow-hidden bg-[#04081A] pb-20 pt-32">
      {/* Grid backdrop, senada dengan section lain */}
      <div className="pointer-events-none absolute inset-0 bg-[linear-gradient(rgba(217,164,65,0.06)_1px,transparent_1px),linear-gradient(90deg,rgba(217,164,65,0.06)_1px,transparent_1px)] bg-[size:40px_40px] [mask-image:radial-gradient(ellipse_80%_80%_at_50%_50%,#000_70%,transparent_100%)]" />

      <div className="relative container mx-auto px-6">
        {/* Header */}
        <div className="mx-auto mb-20 max-w-2xl text-center">
          <h2 className="text-4xl font-medium text-white sm:text-5xl">
            Professional Journey
          </h2>
          <p className="mt-4 text-lg text-gray-400">
            Membangun solusi digital dari kode hingga riset, satu proyek dalam satu waktu.
          </p>
        </div>

        {/* Timeline */}
        <div ref={railRef} className="relative mx-auto max-w-3xl">
          {/* Rel dasar (statis) */}
          <div className="absolute left-5 top-2 bottom-2 w-px bg-gray-700/40" />
          {/* Rel progres — terisi mengikuti posisi scroll */}
          <motion.div
            style={{ height: progressHeight }}
            className="absolute left-5 top-2 w-px bg-gradient-to-b from-amber-400 to-amber-500/20"
          />

          {experiences.map((exp, index) => {
            const showYear = exp.year !== lastYear;
            lastYear = exp.year;
            return (
              <React.Fragment key={index}>
                {showYear && <YearMarker year={exp.year} />}
                <TimelineItem {...exp} />
              </React.Fragment>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default ExperienceSection;