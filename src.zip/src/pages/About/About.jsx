import HeroImg from "@/assets/images/Alfindra Habib BG Merah.png";

const stats = [
  { value: "3.74", label: "IPK / 4.00" },
  { value: "3", label: "Hak Cipta terdaftar DJKI" },
];

export default function About() {
  return (
    <section id="about" className="bg-[#04081A] py-16 text-white md:py-32">
      <div className="mx-auto max-w-5xl px-6">
        <h2 className="max-w-2xl text-4xl font-medium leading-tight text-white lg:text-5xl">
          Developer, Researcher, Innovator
        </h2>

        {/* Angka pencapaian sebagai lanjutan langsung dari headline */}
        <div className="mt-10 flex max-w-xl gap-8 border-t border-white/10 pt-8">
          {stats.map((stat, index) => (
            <div
              key={index}
              className={
                index > 0
                  ? "border-l border-white/10 pl-8"
                  : ""
              }
            >
              <div className="text-3xl font-semibold text-amber-400 lg:text-4xl">
                {stat.value}
              </div>
              <div className="mt-1 text-sm text-gray-400">{stat.label}</div>
            </div>
          ))}
        </div>

        <div className="mt-16 grid gap-10 sm:grid-cols-2 md:gap-16 lg:gap-24">
          <div className="relative">
            <div className="absolute -inset-1 rounded-2xl bg-gradient-to-br from-amber-400/40 via-amber-400/5 to-transparent blur-sm" />
            <div className="relative aspect-[3/4] overflow-hidden rounded-2xl border border-white/10">
              <img
                src={HeroImg}
                className="h-full w-full object-cover object-top"
                alt="Alfindra Habib Nugroho"
                width={929}
                height={1207}
              />
            </div>
          </div>

          <div className="space-y-5">
            <p className="text-gray-300">
              Halo! Saya Alfindra Habib Nugroho, seorang Full-Stack &amp;
              Software Engineer yang berfokus pada pengembangan aplikasi web
              dan mobile menggunakan Laravel, React, Flask, dan Flutter,
              dengan ketertarikan besar pada penerapan Machine Learning untuk
              menyelesaikan masalah nyata.
            </p>
            <p className="text-gray-300">
              Fokus saya adalah membangun aplikasi yang tidak hanya
              fungsional, tapi juga efisien dan mudah digunakan. Saat ini
              saya terus memperdalam riset di bidang Machine Learning &amp;
              Sistem Pakar, sambil terus mengasah kemampuan full-stack
              development untuk membangun produk yang solid dari sisi
              frontend hingga backend.
            </p>

            <div className="relative pt-8">
              <span className="pointer-events-none absolute -top-2 left-0 font-serif text-7xl leading-none text-amber-400/20">
                &ldquo;
              </span>
              <blockquote className="relative pl-2">
                <p className="text-gray-200">
                  Saya percaya belajar adalah proses tanpa akhir. Melalui
                  riset bersama dosen dan tim, saya ikut menghasilkan
                  beberapa Program Komputer yang terdaftar di DJKI, salah
                  satunya Farmonaut — aplikasi klasifikasi penyakit daun padi
                  berbasis CNN Transfer Learning. Saya ingin terus
                  berkontribusi membangun solusi teknologi yang memberi
                  dampak nyata.
                </p>
                <div className="mt-5 flex items-center gap-3">
                  <div className="h-px w-8 bg-amber-400/60" />
                  <cite className="not-italic text-sm font-medium text-white">
                    Alfindra Habib Nugroho, Creator of Farmonaut
                  </cite>
                </div>
              </blockquote>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}